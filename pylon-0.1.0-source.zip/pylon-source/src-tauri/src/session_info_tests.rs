use super::*;

#[test]
fn export_sanitizer_removes_secret_payloads() {
    let messages = vec![serde_json::json!({
        "update": {
            "sessionUpdate": "agent_message_chunk",
            "content": {"text": "visible"},
            "rawInput": {"prompt": "private"},
            "rawOutput": "private output",
            "headers": {"authorization": "Bearer secret"},
            "safe": "kept"
        }
    })];
    let safe = sanitize_export_messages(&messages);
    let text = serde_json::to_string(&safe).expect("serialize sanitized export");
    assert!(text.contains("visible"));
    assert!(text.contains("kept"));
    assert!(!text.contains("private"));
    assert!(!text.contains("secret"));
}

#[test]
fn export_file_write_rejects_existing_path_and_commits_new_file() {
    let root = std::env::temp_dir().join(format!("pylon-export-test-{}", std::process::id()));
    std::fs::create_dir_all(&root).expect("create export test directory");
    let output = root.join("session.json");
    write_export_atomically(&output, b"first").expect("write export");
    assert_eq!(
        std::fs::read_to_string(&output).expect("read export"),
        "first"
    );
    assert!(write_export_atomically(&output, b"second").is_err());
    assert_eq!(
        std::fs::read_to_string(&output).expect("read export"),
        "first"
    );
    std::fs::remove_dir_all(&root).expect("remove export test directory");
}

#[test]
fn export_session_owner_requires_active_generation_match() {
    assert!(is_export_sensitive_key("rawInput"));
    assert!(is_export_sensitive_key("tokenValue"));
    assert!(!is_export_sensitive_key("safe"));
}

#[test]
fn session_response_preserves_mode_and_all_config_options() {
    let mut session = SessionInfo::new(
        "peri-1".into(),
        "persona".into(),
        "G:/work".into(),
        false,
        0,
    );
    session.apply_session_response(&serde_json::json!({
        "modes": {"currentModeId": "plan"},
        "configOptions": [
            {"id": "model", "currentValue": "deepseek-chat"},
            {"id": "thinking", "currentValue": "high"}
        ]
    }));
    assert_eq!(session.mode.as_deref(), Some("plan"));
    assert_eq!(session.model, "deepseek-chat");
    assert_eq!(session.config_options.len(), 2);
}

#[test]
fn config_option_update_accepts_nested_value_shape() {
    let option =
        serde_json::json!({"id": "model", "value": {"valueId": {"value": "deepseek-reasoner"}}});
    assert_eq!(
        config_option_current_value(&option).as_deref(),
        Some("deepseek-reasoner")
    );
}

#[test]
fn mode_falls_back_to_mode_config_option() {
    let mut session = SessionInfo::new("peri-1".into(), String::new(), ".".into(), true, 0);
    session.apply_session_response(&serde_json::json!({
        "configOptions": [{"id": "mode", "currentValue": "code"}]
    }));
    assert_eq!(session.mode.as_deref(), Some("code"));
}

#[test]
fn keep_sessions_migrates_generation() {
    let mut sessions = HashMap::new();
    sessions.insert(
        "source-a".into(),
        SessionInfo::new("peri-1".into(), "persona".into(), ".".into(), true, 1),
    );
    sessions.insert(
        "source-b".into(),
        SessionInfo::new("peri-2".into(), "persona".into(), ".".into(), true, 1),
    );
    apply_client_replacement_sessions(&mut sessions, true, 9);
    assert_eq!(sessions.len(), 2);
    for session in sessions.values() {
        assert_eq!(session.generation, 9);
    }
}

#[test]
fn keep_sessions_false_clears_sessions() {
    let mut sessions = HashMap::new();
    sessions.insert(
        "source-a".into(),
        SessionInfo::new("peri-1".into(), "persona".into(), ".".into(), true, 1),
    );
    apply_client_replacement_sessions(&mut sessions, false, 9);
    assert!(sessions.is_empty());
}

/// 优化-1：keep=false 客户端替换（switch/重连）后 prompt 锁表必须收敛——
/// 与 replace_agent_client 同序列：锁内快照旧 source → 清空映射 → 锁外清理；
/// 无会话映射的孤儿锁条目不在清理范围（保守作用域）。
#[test]
fn keep_sessions_false_drops_stale_prompt_locks() {
    let runtime = AgentRuntime::new_disconnected();
    {
        let mut sessions = runtime.sessions.lock().unwrap();
        sessions.insert(
            "source-a".into(),
            SessionInfo::new("peri-1".into(), "persona".into(), ".".into(), true, 1),
        );
        sessions.insert(
            "qq:u-123".into(),
            SessionInfo::new("peri-2".into(), "persona".into(), ".".into(), true, 1),
        );
    }
    for source in ["source-a", "qq:u-123", "orphan-lock"] {
        prompt_lock_for(&runtime.prompt_locks, source);
    }
    assert_eq!(runtime.prompt_locks.lock().unwrap().len(), 3);
    let stale_sources: Vec<String> = {
        let mut sessions = runtime.sessions.lock().unwrap();
        let stale = sessions.keys().cloned().collect();
        apply_client_replacement_sessions(&mut sessions, false, 9);
        stale
    };
    // G2-08：收敛为 runtime 方法（与 replace_agent_client 同序列语义）
    runtime.drop_prompt_locks(&stale_sources);
    assert!(runtime.sessions.lock().unwrap().is_empty());
    let locks = runtime.prompt_locks.lock().unwrap();
    assert!(
        !locks.contains_key("source-a") && !locks.contains_key("qq:u-123"),
        "旧 source 锁条目必须随映射清空收敛"
    );
    assert!(
        locks.contains_key("orphan-lock"),
        "无会话映射的孤儿锁不在清理范围"
    );
}

#[test]
fn inspector_aggregates_session_stats() {
    let mut sessions = HashMap::new();
    let mut s1 = SessionInfo::new("peri-1".into(), "p1".into(), ".".into(), true, 0);
    s1.tokens_in = 100;
    s1.tokens_out = 50;
    s1.tokens_total = 150;
    s1.context_size = 8192;
    s1.model = "model-a".into();
    let mut s2 = SessionInfo::new("peri-2".into(), "p2".into(), "/work".into(), false, 0);
    s2.tokens_in = 20;
    s2.tokens_out = 10;
    s2.tokens_total = 30;
    s2.context_size = 4096;
    sessions.insert("source-a".into(), s1);
    sessions.insert("source-b".into(), s2);
    let runtime = AgentRuntimeState {
        status: AgentLifecycleStatus::Connected,
        last_error: None,
        last_connected_at: Some(Timestamp::new(1)),
    };
    let entries = vec![("agent-x".to_string(), sessions, runtime)];
    let payload = build_full_inspector_payload(&entries, "agent-x");
    assert_eq!(payload["agent"]["id"], "agent-x");
    assert_eq!(payload["agent"]["status"], "connected");
    assert_eq!(payload["summary"]["sessionCount"], 2);
    assert_eq!(payload["summary"]["activeCount"], 1); // 仅 s1 有 first prompt
    assert_eq!(payload["summary"]["tokensTotal"], 180);
    assert_eq!(payload["summary"]["tokensIn"], 120);
    assert_eq!(payload["summary"]["tokensOut"], 60);
    let rows = payload["sessions"]
        .as_array()
        .expect("sessions must be array");
    assert_eq!(rows.len(), 2);
    let rows_by_source: HashMap<&str, &serde_json::Value> = rows
        .iter()
        .map(|r| (r["source"].as_str().unwrap(), r))
        .collect();
    assert_eq!(rows_by_source["source-a"]["tokensTotal"], 150);
    assert_eq!(rows_by_source["source-b"]["cwd"], "/work");
    assert_eq!(rows_by_source["source-a"]["model"], "model-a");
    assert_eq!(
        rows_by_source["source-a"]["agentId"], "agent-x",
        "session 行必须带 agentId 区分来源"
    );
    // B2 增量：runtimes 数组 + workspace 映射
    let runtimes = payload["runtimes"]
        .as_array()
        .expect("runtimes must be array");
    assert_eq!(runtimes.len(), 1);
    assert_eq!(runtimes[0]["agentId"], "agent-x");
    assert_eq!(runtimes[0]["status"], "connected");
    assert_eq!(runtimes[0]["sessionCount"], 2);
    assert_eq!(runtimes[0]["tokensTotal"], 180);
    assert!(
        payload["workspace"].get("source-a").is_some(),
        "workspace 必须含每个 source 的 root 状态"
    );
}

#[test]
fn inspector_full_aggregates_across_runtimes() {
    let mut sessions_a = HashMap::new();
    let s1 = SessionInfo::new("peri-a".into(), "pa".into(), ".".into(), true, 0);
    sessions_a.insert("local".into(), s1);
    let mut sessions_b = HashMap::new();
    let s2 = SessionInfo::new("peri-b".into(), "pb".into(), ".".into(), false, 0);
    sessions_b.insert("qq:group:1".into(), s2);
    let state_a = AgentRuntimeState {
        status: AgentLifecycleStatus::Connected,
        last_error: None,
        last_connected_at: Some(Timestamp::new(1)),
    };
    let state_b = AgentRuntimeState {
        status: AgentLifecycleStatus::Crashed,
        last_error: Some("boom".into()),
        last_connected_at: None,
    };
    let entries = vec![
        ("peri".to_string(), sessions_a, state_a),
        ("hermes".to_string(), sessions_b, state_b),
    ];
    let payload = build_full_inspector_payload(&entries, "peri");
    assert_eq!(payload["summary"]["sessionCount"], 2, "跨 runtime 全局聚合");
    assert_eq!(payload["summary"]["activeCount"], 1);
    let runtimes = payload["runtimes"].as_array().expect("runtimes array");
    assert_eq!(runtimes.len(), 2);
    let crashed = runtimes
        .iter()
        .find(|r| r["agentId"] == "hermes")
        .expect("hermes runtime");
    assert_eq!(crashed["status"], "crashed");
    assert_eq!(crashed["lastError"], "boom");
    assert_eq!(crashed["sessionCount"], 1);
    let rows = payload["sessions"].as_array().expect("sessions array");
    let qq_row = rows
        .iter()
        .find(|r| r["source"] == "qq:group:1")
        .expect("qq session");
    assert_eq!(
        qq_row["agentId"], "hermes",
        "跨 runtime session 必须可区分来源"
    );
}

#[test]
fn session_expiry_idle_threshold_and_off_mode() {
    let now = Timestamp::new(1722500000000);
    // idle：超过阈值过期
    assert_eq!(
        session_expired(Some(Timestamp::new(1722490000000)), now, "idle", 30).as_deref(),
        Some("超过 30 分钟无活动")
    );
    // 31 分钟前（1860000ms）应过期
    assert!(
        session_expired(Some(Timestamp::new(1722498140000)), now, "idle", 30).is_some(),
        "31 分钟前应过期"
    );
    // 1 分钟内未过期
    assert!(
        session_expired(Some(Timestamp::new(1722499900000)), now, "idle", 30).is_none(),
        "1 分钟内未过期"
    );
    // off：永不过期
    assert_eq!(
        session_expired(Some(Timestamp::new(1)), now, "off", 1),
        None
    );
    // updated_at 缺失：保守不过期
    assert_eq!(session_expired(None, now, "idle", 1), None);
}

#[test]
fn session_expiry_daily_mode_compares_calendar_day() {
    let now = Timestamp::new(1722500000000); // 某日
    assert!(
        session_expired(Some(Timestamp::new(1722400000000)), now, "daily", 0).is_some(),
        "跨天应过期"
    );
    assert!(
        session_expired(Some(Timestamp::new(1722500000000)), now, "daily", 0).is_none(),
        "同天未过期"
    );
    // 同一天但 23 小时前：daily 不过期（idle 才看时长）
    let same_day_later = Timestamp::new(1722490000000);
    assert_eq!(session_expired(Some(same_day_later), now, "daily", 0), None);
}

#[test]
fn parse_permission_request_extracts_fields_and_sanitizes_prompt() {
    let params = serde_json::json!({
        "sessionId": "session-1",
        "toolCall": {
            "toolCallId": "call-1",
            "title": "edit_file",
            "rawInput": "{\"path\": \"/tmp/x\", \"token=SECRET\"}"
        },
        "options": [
            {"optionId": "allow_once", "name": "Allow once", "kind": "allowOnce"},
            {"optionId": "reject_once", "name": "Reject", "kind": "rejectOnce"}
        ]
    });
    let permission = parse_permission_request(Some(&params)).expect("合法请求必须解析");
    assert_eq!(permission.session_id, "session-1");
    assert_eq!(permission.tool_call_id, "call-1");
    assert_eq!(permission.title, "edit_file");
    assert_eq!(permission.options, vec!["allow_once", "reject_once"]);
    // prompt 脱敏：token= 载荷被 REDACTED
    assert!(
        !permission.prompt.contains("SECRET"),
        "prompt 不得含 secret 载荷: {}",
        permission.prompt
    );
    assert!(permission.prompt.contains("[REDACTED]"));
}

#[test]
fn parse_permission_request_rejects_malformed_shapes() {
    // 缺 toolCall
    assert!(parse_permission_request(Some(&serde_json::json!({
        "sessionId": "s1", "options": [{"optionId": "allow_once"}]
    })))
    .is_none());
    // 缺 toolCallId
    assert!(parse_permission_request(Some(&serde_json::json!({
        "sessionId": "s1", "toolCall": {"title": "t"}, "options": [{"optionId": "allow_once"}]
    })))
    .is_none());
    // 空选项
    assert!(parse_permission_request(Some(&serde_json::json!({
        "sessionId": "s1", "toolCall": {"toolCallId": "c1"}, "options": []
    })))
    .is_none());
    // 缺 params
    assert!(parse_permission_request(None).is_none());
}

#[test]
fn permission_response_wire_shapes_are_stable() {
    // RequestPermissionOutcome 是 internally tagged（tag="outcome"）：
    // Selected → {"outcome": {"outcome": "selected", "optionId": "..."}}
    let selected = permission_response("allow_once");
    assert_eq!(selected["outcome"]["outcome"], "selected");
    assert_eq!(selected["outcome"]["optionId"], "allow_once");
    let rejected = permission_response("reject_once");
    assert_eq!(rejected["outcome"]["optionId"], "reject_once");
    let cancelled = permission_response_cancelled();
    assert_eq!(cancelled["outcome"]["outcome"], "cancelled");
}

#[tokio::test]
async fn resolve_permission_responds_and_clears_pending() {
    let runtime = AgentRuntime::new_disconnected();
    let permission = parse_permission_request(Some(&serde_json::json!({
        "sessionId": "s1",
        "toolCall": {"toolCallId": "call-1", "title": "tool"},
        "options": [{"optionId": "allow_once"}, {"optionId": "reject_once"}]
    })))
    .expect("parse");
    runtime
        .pending_permissions
        .lock()
        .unwrap()
        .insert(7, permission);
    // 非法选项拒绝
    assert!(resolve_permission(&runtime, 7, "allow_always")
        .await
        .is_err());
    // 未找到拒绝
    assert!(resolve_permission(&runtime, 99, "allow_once")
        .await
        .is_err());
    // 合法应答：disconnected client 写通道关闭 → 发送失败，但 pending 已清理？
    // disconnected client 的 write_tx send 会失败（无接收端）——resolve 返回 Err 且 pending 保留。
    // 用真实 fake ACP 覆盖发送成功路径（见集成测试）。
    let result = resolve_permission(&runtime, 7, "reject_once").await;
    assert!(result.is_err(), "disconnected client 发送应失败");
    // 失败后 pending 保留（可重试）
    assert!(runtime.pending_permissions.lock().unwrap().contains_key(&7));
}
