import { lazy, Suspense } from 'react'
import { useWorkspaceStore } from '../workspaceStore'
import { SHEET_REGISTRY } from './sheetRegistry'
import AgentSheetView from '../sheets/AgentSheetView'
import type { SheetRecord } from './sheetTypes'

// Prism 管理 Sheet 非首屏：按需分包
const PrismManagerSheetView = lazy(() => import('../sheets/PrismManagerSheetView'))

interface SheetHostProps {
  activeSession: string | null
  onSelectSession: (id: string | null) => void
  onProfileEdit: () => void
  onSessionSettings: (id: string) => void
  sidebarCollapsed: boolean
  rightInset: number
  ccEditMode: boolean
}

export default function SheetHost(props: SheetHostProps) {
  const sheets = useWorkspaceStore(s => s.workspaceSheets.sheets)
  const activeSheetId = useWorkspaceStore(s => s.workspaceSheets.activeSheetId)
  const activeSheet = sheets.find(sheet => sheet.id === activeSheetId)

  if (!activeSheet) return <EmptySheetHost />
  return <SheetRenderer sheet={activeSheet} {...props} />
}

function SheetRenderer({ sheet, ...props }: { sheet: SheetRecord } & SheetHostProps) {
  const renderKey = SHEET_REGISTRY[sheet.kind]?.renderKey ?? 'unknown'
  switch (renderKey) {
    case 'agent-sheet':
      return <AgentSheetView sheet={sheet} {...props} />
    case 'prism-manager-sheet':
      return (
        <Suspense fallback={
          <div className="sheet-empty-host">
            <div className="sheet-empty-kicker">LOADING</div>
            <p>加载模块…</p>
          </div>
        }>
          <PrismManagerSheetView />
        </Suspense>
      )
    default:
      return <UnavailableSheet kind={sheet.kind} />
  }
}

function EmptySheetHost() {
  const openSheet = useWorkspaceStore(s => s.openSheet)
  return (
    <div className="sheet-empty-host">
      <div className="sheet-empty-kicker">WORKSPACE</div>
      <h2>没有打开的 Sheet</h2>
      <p>打开一个 Agent 工作现场，或从工具入口选择 Sheet。</p>
      <button type="button" onClick={() => openSheet({ kind: 'agent', title: 'Riccati', agentId: 'riccati' })}>
        打开 Riccati
      </button>
    </div>
  )
}

function UnavailableSheet({ kind }: { kind: string }) {
  return (
    <div className="sheet-empty-host">
      <div className="sheet-empty-kicker">SHEET</div>
      <h2>{kind} 尚未接入</h2>
      <p>当前只建立了 Sheet 状态与导航壳，运行内容尚未接入。</p>
    </div>
  )
}
